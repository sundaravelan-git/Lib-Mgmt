<?php
$conn= mysqli_connect('localhost','root',''); 
$db=mysqli_select_db($conn,'library_mgmt');


	$email   = $_POST['u_eid'];
	$user    = $_POST['u_name'];
	$pwd     = $_POST['u_pwd'];
	$role	 = $_POST['role'];
	$opt	 = $_POST['lib_choice'];
	
	
	if($opt=='Add_User/Librarian')
	{
	$result=mysqli_query($conn,"insert into user values('','".$role."','".$email."','".$user."','".$pwd."')");
	if($role==1)	
	mysqli_query($conn,"insert into history_user values('','".$email."','".$user."','Administrator',CURDATE(),'inserted')");
	else if($role==2)
			mysqli_query($conn,"insert into history_user values('','".$email."','".$user."','Librarian',CURDATE(),'inserted')");
	else
			mysqli_query($conn,"insert into history_user values('','".$email."','".$user."','User',CURDATE(),'inserted')");


	
	if($result)
	{
				echo"<script type='text/javascript'>alert('sucessfull insertion');window.location='mng_usr.php';</script>";

	}
	else
	{
				echo"<script type='text/javascript'>alert('failure insertion');window.location='mng_usr.php';</script>";

	}
	}
	else
	{
		$result=mysqli_query($conn,"delete from user where email='".$email."';");
		if($role==1)	
	mysqli_query($conn,"insert into history_user values('','".$email."','".$user."','Administrator',CURDATE(),'deleted')");
	else if($role==2)
			mysqli_query($conn,"insert into history_user values('','".$email."','".$user."','Librarian',CURDATE(),'deleted')");
	else
			mysqli_query($conn,"insert into history_user values('','".$email."','".$user."','User',CURDATE(),'deleted')");

		if($result)
	{
				echo"<script type='text/javascript'>alert('Deletion Sucess');window.location='mng_usr.php';</script>";

	}
	else
	{
				echo"<script type='text/javascript'>alert('Deletion Fails');window.location='mng_usr.php';</script>";

	}
	}
			
	

?>