<?php 
//include("users.php");
session_start();
if (!isset($_SESSION['login_user'])){
	header('Location:index.php');
	//$use
}?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>home</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<script type="text/javascript" src="jquery.min.js"></script>
    <script type="text/javascript">
        $("#btnPrint").live("click", function () {
			
            var divContents = $("#main_content_id").html();
            var printWindow = window.open('', '', 'height=400,width=800');
            printWindow.document.write('<html><head><h2 align="center">User Returned Book Detials</title>');
            printWindow.document.write('</head><body >');
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>
<body onload='window.location.hash="#btnPrint";'>
<div id="wrapper">
<div id="logo">
	<h1><a href="#">Library Management System</a></h1>
	<div class="profilename_sec">
	<label><?php echo $_SESSION['users_details']['username'];?></label>
	<img src="images/usersico.png" class="usericon"/>
	</div>
	<p>THIAGARAJAR COLLEGE OF ENGINEERING</p>
</div>
<div id="header">
	<div id="menu">
		<ul>
			<li class="current_page_item"><a href="home.php">Home</a></li>
			<?php if($_SESSION['users_details']['role'] == 1){?>
			<li><a href="search.php">Search</a></li>
			<li><a href="user_issuedbook.php">Issued Books</a></li>
			<li><a href="users_renuedbook.php">Renued Books</a></li>
			<li><a href="users_returned.php">Returned Book</a></li>
						
			<?php }
			else if($_SESSION['users_details']['role'] == 2){?>
			<li><a href="issue_book.php">Issue Books</a></li>
			<li><a href="#">Renue Books</a></li>
			<li><a href="#">Return Books</a></li>
			<?php }else{?>
			<li><a href="#">Manage Librian</a></li>
			<li><a href="#">Manage Book Details</a></li>
			<li><a href="#">Manage Users</a></li>
			<?php }?>
			<li><a href="logout.php">logout</a></li>
		</ul>
	</div>
	<div id="gallery"><img src="images/sam.jpg" width="683" height="340" alt="" /></div>
	
</div>
<div>
<div class="main-content" id='main_content_id'>
<div class="head_text" id="test" action="issue_book.php">
<p>Over all Book Status</p>
<?php	
	$conn= mysqli_connect('localhost','root',''); 
$db=mysqli_select_db($conn,'library_mgmt');	



      echo "<table border=1 align=center>
				<tr>
				<th><a href='user_issuedbook.php'>ISSUED</th></a>
				<th><a href='users_renuedbook.php'>RENUED</a></th>
				<th><a href='users_returned.php'>RETURNED</a></th>
				</tr>";
			$result = mysqli_query($conn,"select count(*) from issued where email = '".$_SESSION['users_details']['email']."';") or die(mysql_error());
			$row = mysqli_fetch_array($result);

			if($results=mysqli_num_rows($result))
				
			
			{
				echo"<tr>
				<td>'".$row[0]."'</td>";
				
			}
			$result = mysqli_query($conn,"select count(*) from renued where email = '".$_SESSION['users_details']['email']."';") or die(mysql_error());
			$row = mysqli_fetch_array($result);

			if($results=mysqli_num_rows($result))
			{
				echo"
				<td>'".$row[0]."'</td>";
				
			}
			$result = mysqli_query($conn,"select count(*) from returned where email = '".$_SESSION['users_details']['email']."';") or die(mysql_error());
			$row = mysqli_fetch_array($result);

			if($results=mysqli_num_rows($result))
			{
				echo"
				<td>'".$row[0]."'</td>";
				
			}
			echo"</tr></table>"
			
         

?>
</div>
<div class="head_text" id="test" action="issue_book.php" align=center>
	
	<p>Renued Books</p>
		<?php
$conn= mysqli_connect('localhost','root',''); 
$db=mysqli_select_db($conn,'library_mgmt');	


$result = mysqli_query($conn,"select * from returned where email = '".$_SESSION['users_details']['email']."';") or die(mysql_error());

	   echo "<table  class='overall_tab' border=1>
				<tr>
				<th>Email_ID</th>
				<th>ACCESSION_NO</th>
				<th>DATE</th>
				</tr>";
			
	if(mysqli_num_rows($result)){
           while($results = mysqli_fetch_array($result)){
             
           
				echo"	
				
				<tr>
					<td>
					'".$results['email']."'
					</td>
					
					<td>
					'".$results['accession_no']."'
					</td>
					
					<td>
					'".$results['DOR']."'
					</td>
					
				</tr>";
                // posts results gotten from database(title and text) you can also show id ($results['id'])
            }
			echo"</table>";
		            
             
        }
        else{ // if there is no matching rows do following
            echo "No results";
			
		
        }
         

?>
	
</div>
<div align=center>
<B><Button id="btnPrint">Prepare a report of your Usage</Button></td>
</div>
</div>
</div>

</html>