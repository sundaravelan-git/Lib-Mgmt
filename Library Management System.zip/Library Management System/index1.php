<?php 
//include("users.php");
session_start();
if (isset($_SESSION['login_user'])) header('Location:home.php');
  
?>
<!DOCTYPE html>
<!-- saved from url=(0037)https://librarycom.000webhostapp.com/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	
	<title>Log-in</title>
	<!--<base href="https://librarycom.000webhostapp.com/">--><base href=".">
			<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		<meta name="description" content="">
	<meta name="keywords" content="">
	<!-- Facebook Open Graph -->
	<meta name="og:title" content="Home">
	<meta name="og:description" content="">
	<meta name="og:image" content="">
	<meta name="og:type" content="article">
	<meta name="og:url" content="https://librarycom.000webhostapp.com/">
	<!-- Facebook Open Graph end -->
		
	<link href="./Home_files/bootstrap.min.css" rel="stylesheet" type="text/css">
	<script src="./Home_files/jquery-1.11.3.min.js.download" type="text/javascript"></script>
	<script src="./Home_files/bootstrap.min.js.download" type="text/javascript"></script>
	<script src="./Home_files/main.js.download" type="text/javascript"></script>


	<link href="./Home_files/site.css" rel="stylesheet" type="text/css">
	<link href="./Home_files/common.css" rel="stylesheet" type="text/css">
	<link href="./Home_files/1.css" rel="stylesheet" type="text/css">
		<script src="js/index.js"></script>

	<style>
body select { 
display: block;
padding: 10px 70px 10px 13px !important;
max-width: 100%;
height: auto !important;
border: 1px solid #e3e3e3;
border-radius: 3px; background: url("https://image.ibb.co/iMeAJv/selectbox_arrow.png") right center no-repeat;
background-color: #fff; color: #444444;
font-size: 18px;
background: rgba(23, 24, 25, 0.29) url("../images/pass.png") no-repeat 11px 10px;
opacity: 0.4;
font-family: Oswald-Light;
color:white;
line-height: 16px !important;
appearance: none;
-webkit-appearance: none;
-moz-appearance: none; }
body select option { padding: 0 4px; }
</style>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:400,300'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/icon?family=Material+Icons'>
<link rel="stylesheet" href="css/style.css">
	
	<script type="text/javascript">var currLang = 'en';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>
 <script src="js/index.js"></script>

<body><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_cs_row_1" class="wb-cs-row"><div id="wb_cs_col_2" class="wb-cs-col"><div id="wb_cs_row_3" class="wb-cs-row"><div id="wb_cs_col_4" class="wb-cs-col"><div id="wb_element_instance2" class="wb_element wb_element_picture wb-cs-elem"><img alt="gallery/thiagarajar-college-of-engineering" src="./Home_files/57a81e0be1608b0a6b094b4b642440e6_40x37.png"></div></div><div id="wb_cs_col_5" class="wb-cs-col"><div id="wb_element_instance1" class="wb_element wb-cs-elem" style=" line-height: normal;"><h4 class="wb-stl-pagetitle">Thiagarajar college of Enggineering.</h4>
</div></div><div class="wb-cs-clear"></div></div></div><div id="wb_cs_col_6" class="wb-cs-col wb-cs-right"><div id="wb_element_instance0" class="wb_element wb-menu wb-menu-mobile wb-cs-elem"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu"><li class="active"><a href="index.html" target="_self" title="HOME">HOME</a></li><li><a href="About us.html" target="_self" title="About us">About us</a></li><li><a href="Contacts.html" target="_self" title="Contacts">Contacts</a></li><li><a href="index1.php" target="_self" title="Login">Login</a></li></ul><div class="clearfix"></div></div></div><div class="wb-cs-clear"></div></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_cs_row_9" class="wb-cs-row"><div id="wb_cs_col_10" class="wb-cs-col"><div id="wb_element_instance11" class="wb_element wb-cs-elem" style=" line-height: normal;"><p style="text-align: justify;">&nbsp;</p>

<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:400,300'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/icon?family=Material+Icons'>

      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

<div class="cont_centrar" id="s1">

  <div class="cont_login">
<div class="cont_info_log_sign_up" style="width:1000px,position:fixed">
      <div class="col_md_login"  style="position:fixed">
<div class="cont_ba_opcitiy" >

        
        <h2>LOGIN</h2>  
  <p>If u are an existing user,please log_in!!!.</p> 
  <button class="btn_login" onclick="cambiar_login()">LOGIN</button>
  </div>
  </div>
<div class="col_md_sign_up">

  </div>
       </div>
<div class="cont_forms" style="width:640px">
    
    
	   <form method=post action=login.php>
 <div class="cont_form_login" style="position:relative">
<a href="#" onclick="ocultar_login_sign_up()" ><i class="material-icons">&#xE5C4;</i></a>
   <h2>LOGIN</h2>
 <input type="text" placeholder="Email" name='email' />
<input type="password" placeholder="Password" name='pwd'/>
<br><br>

<button class="btn_login" name=butt_login >LOGIN</button>
  </div>
  </form>
  
 <form method=post action=registration.php>

   <div class="cont_form_sign_up">
         <div class="col_md_login" style="position:fixed">

   
   <form method=post action=registration.php>
<a href="#" onclick="ocultar_login_sign_up()"><i class="material-icons">&#xE5C4;</i></a>
     <h2>SIGN UP</h2>
	  
<input type="text" placeholder="Email" name='email'/>
<input type="text" placeholder="User" name='user' />
<input type="password" placeholder="Password" name='password' />
<br/><br/>

<button class="btn_sign_up">SIGN UP</button>

  </div>
  </form>
   
    </div>
    
  </div>
 </div>
</div>
  



	
<div id="wb_cs_row_7" class="wb-cs-row"><div id="wb_cs_col_8" class="wb-cs-col"><div id="wb_element_instance3" class="wb_element wb-cs-elem" style=" line-height: normal;">
</div></div><div class="wb-cs-clear"></div></div></div><div class="wb_sbg"></div></div><div style="text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;"><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&amp;utm_campaign=000_logo&amp;utm_medium=website_librarycom&amp;utm_content=footer_img"></a></div>


</body></html>