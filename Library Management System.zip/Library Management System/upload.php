	<?php  
	
	$conn= mysqli_connect('localhost','root',''); 
	$db=mysqli_select_db($conn,'library_mgmt');	
	
	
	$opt_Main=$_POST['upCatMain'];
	
	
	if($_FILES['fileToUpload']['name']==null)
	{
	$Message="Please Upload the file";
	header('Location: bulky.php?Message='.urlencode($Message));
	}
	else
	{
		//Move the file
		$target_path = 'C:/wamp/www/Library Management System/';  
		$target_path = $target_path.basename( $_FILES['fileToUpload']['name']); 
		move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path);
		//variables
		$text=$_POST['status'];
		//open file
		$filename =$_FILES['fileToUpload']['name'] ;    
		$fp = fopen($filename, "r"); 
	
		//main job
		if($opt_Main=="Book")
		{
			$opt=$_POST['upCatBook'];
			if($opt==2)
			{
		
				while($contents = fgetcsv($fp))
				{
				
				$result = mysqli_query($conn,"update sheet1 set STATUS='".$text."' where ACCESSION_NO = '".$contents[0]."';");

					
				}
								echo"<script type='text/javascript'>alert('sucessfull Updation');window.location='bulky.php';</script>";


			}
			else
			{
				$contents = fgetcsv($fp);
				while($contents = fgetcsv($fp))
				{
				
				$result=mysqli_query($conn,"insert into sheet1 values('".$contents[0]."','".$contents[1]."','".$contents[2]."','".$contents[3]."')");					
				}
								echo"<script type='text/javascript'>alert('sucessfull Insertion');window.location='bulky.php';</script>";


			
			}
		}
		else
		{
			$opt=$_POST['upCatUser'];
			if($opt==1)
			{
				$contents = fgetcsv($fp);
				while($contents = fgetcsv($fp))
					{
							$result=mysqli_query($conn,"insert into user values('','".$contents[0]."','".$contents[1]."','".$contents[2]."','".$contents[3]."')");

					}
									echo"<script type='text/javascript'>alert('sucessfull Insertion');window.location='bulky.php';</script>";
			}
			else{
				$contents = fgetcsv($fp);
				while($contents = fgetcsv($fp))
					{
								$result=mysqli_query($conn,"delete from user where email='".$contents[1]."';");

					}
									echo"<script type='text/javascript'>alert('sucessfull Deletion');window.location='bulky.php';</script>";
				
			}
			
		}
	}
	fclose($fp);

	
	
	?>  
