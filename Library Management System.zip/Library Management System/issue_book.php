<?php 
//include("users.php");
session_start();
if (!isset($_SESSION['login_user'])){
	header('Location:index.php');
	//$use
}?>


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>home</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<style>

</style>
<body onload='window.location.hash="#btnPrint";'>

<div id="wrapper">
<div id="logo">
	<h1><a href="#">Library Management System</a></h1>
	<div class="profilename_sec">
	<label><?php echo $_SESSION['users_details']['username'];?></label>
	<img src="images/usersico.png" class="usericon"/>
	</div>
	<p>THIAGARAJAR COLLEGE OF ENGINEERING</p>
</div>
<div id="header">
	<div id="menu">
		<ul>
			<li class="current_page_item"><a href="home.php">Home</a></li>
			<?php if($_SESSION['users_details']['role'] == 1){?>
			<li><a href="#">Dashboard</a></li>
			<li><a href="#">Issued Books</a></li>
			<li><a href="#">Renued Books</a></li>
			<li><a href="#">Returned Book</a></li>
			
			<?php }
			else if($_SESSION['users_details']['role'] == 2){?>
			<li><a href=#">Manage Books</a></li>
			<li><a href="mng_usr_lib.php">Manage user</a></li>
			<li><a href="search.php">Search</a></li>
			
			
			<?php }else{?>
			<li><a href="#">Manage Librian</a></li>
			<li><a href="#">Manage Book Details</a></li>
			<li><a href="#">Manage Users</a></li>
			<?php }?>
			<li><a href="logout.php">logout</a></li>
		</ul>
	</div>
	
	<div id="gallery"><img src="images/sam.jpg" width="683" height="340" alt="" /></div>
	
</div>
<div class="main-content">
<div class="head_text" id="test" action="issue_book.php">
	<p>Manage Books</p>
	<form class="bookstatus_form" id="book_status" method=POST action=issue_book1.php>
		<label> Book Id</label> 
		<input type="text" name="book_id" class="bookid_txt" placeholder="Enter Book id."  id="bookid_txt"/>
		<label> Student ID:</label>
		<input type="text" name="user_id" placeholder="Enter student id" class="userid_txt" id="userid_txt"/>
		<label> Change BookStatus:</label>
		<select name="book_status">
			<option value=1>Issued</option>
			<option value=2>Renued</option>
			<option value=3>Returned</option>
		</select>
		<input type="submit" name="update_book"id='btnPrint' class="btn" value="Submit"/>
	</form>
</div>
</div>
</div>
</html>