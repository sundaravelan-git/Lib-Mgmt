<?php

$conn= mysqli_connect('localhost','root',''); 
$db=mysqli_select_db($conn,'library_mgmt');	

$bid=$_POST['book_id'];
$uid=$_POST['user_id'];
$opt=$_POST['book_status'];


 $result = mysqli_query($conn,"select email from user where email='".$uid."' ;") or die(mysql_error());

			
	if(mysqli_num_rows($result))
	{
		if($opt==1)
		{
			$res=mysqli_query($conn,"insert into issued values('".$uid."','".$bid."',CURRENT_TIMESTAMP)");
			if($res)
			{
					$r=mysqli_query($conn,"update sheet1 set status='issued' where accession_no='".$bid."'");
					echo"<script>alert('success fully issued');window.location='issue_book.php';</script>";



			}
		else{
			echo"<script>alert('not issued');window.location='issue_book.php';</script>";
			
			}
		}
	
		else if($opt==2)
		{
		
			$res=mysqli_query($conn,"insert into renued values('".$uid."','".$bid."',CURRENT_TIMESTAMP)");
			if($res)
			{
				echo"<script>alert('success fully renued');window.location='issue_book.php';</script>";

			}
			else{
				echo"<script>alert('First take the book and then u can renue');window.location='issue_book.php';</script>";

				}
		}
	
	else
		{
				$res=mysqli_query($conn,"insert into returned values('".$uid."','".$bid."',CURRENT_TIMESTAMP)");

	if($res)
			{
					$r=mysqli_query($conn,"update sheet1 set status='AVAILABLE' where accession_no='".$bid."'");
					echo"<script>alert('success fully returned');window.location='issue_book.php';</script>";



			}
			else{
								echo"<script>alert('First take the book and then u can return');window.location='issue_book.php';</script>";

			}
		}
	
	}
	
	
	
         

?>
	