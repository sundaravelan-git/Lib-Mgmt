<?php 
//include("users.php");
session_start();
if (!isset($_SESSION['login_user'])){
	header('Location:index.php');
	//$use
}?>



<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>home</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<style>

</style>
<body onload='window.location.hash="#btnPrint";'>
<div id="wrapper">
<div id="logo">
	<h1><a href="#">Library Management System</a></h1>
	<div class="profilename_sec">
	<label><?php echo $_SESSION['users_details']['username'];?></label>
	<img src="images/usersico.png" class="usericon"/>
	</div>
	<p>THIAGARAJAR COLLEGE OF ENGINEERING</p>
</div>
<div id="header" class="sam" style="height:430px">
	<div id="menu_admin" style="background-size:308px 430px;">
		<ul>
			<li class="current_page_item"><a href="home.php">Home</a></li>
			<?php if($_SESSION['users_details']['role'] == 1){?>
			<li><a href="#">Dashboard</a></li>
			<li><a href="#">Issued Books</a></li>
			<li><a href="#">Renued Books</a></li>
			<li><a href="#">Returned Book</a></li>
			
			<?php }
			else if($_SESSION['users_details']['role'] == 2){?>
			<li><a href=#">Manage Books</a></li>
			
			
			<?php }else{?>
			<li><a href="mng_usr.php">Manage Librian</a></li>
			<li><a href="#">Manage Book Details</a></li>
			<li><a href="mng_usr.php">Manage Users</a></li>
			<li><a href="search.php">Search</a></li>
			<li><a href="mng_usr_lib.php">Generate Report</a></li>
			<li><a href="history.php">History</a></li>
			<li><a href="Bulky.php">Upload File</a></li>
			
			
			
			<?php }?>
			<li><a href="logout.php">logout</a></li>
		</ul>
	</div>
	
	<div id="gallery"><img src="images/sam.jpg" width="680" height="428" alt="" /></div>
	
</div>
<div class="main-content">
<div class="head_text" id="test" action="issue_book.php">
	<p>Manage Books</p>
	<form class="bookstatus_form" id="book_status" method=POST action=mng_book1.php>
		<label>Accession_number</label> 
		<input type="text" name="acc_no" class="bookid_txt" placeholder="Enter accession Number"  id="acc_no_txt"/>
		<label>Author :</label>
		<input type="text" name="author" placeholder="Enter Author name" class="userid_txt" id="author_txt"/>
		<label>Book_Name: :</label>
		<input type="text" name="book_name" placeholder="Enter Name of the book" class="userid_txt" id="book_name_txt"/>
		<label>Status:</label>
		<select name="book_status">
			<option>----Choose any one----</option>
			<option>AVAILABLE</option>
			<option>ISSUED</option>
			<option>RENUED</option>
			<option>DAMAGED</option>
			<option>MISSED</option>
			<option>TRANSFERED</option>
			<option>BINDING</option>
		</select>
		<label>Operation</label>
		<select name='opr'>
			<option>---- Choose any one ----</option>
			<option>Insert Data</option>
			<option>Update Data</option>
			<option>Delete Data</option>
		
		</select>
		
		<input type="submit" name="update_book" id='btnPrint' class="btn" value="Submit"/>
	</form>
</div>
</div>
</div>
</html>