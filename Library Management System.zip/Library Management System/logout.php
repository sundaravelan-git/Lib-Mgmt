<?php

	session_start();
	if (isset($_SESSION['login_user'])){
		unset($_SESSION['login_user']);
	}		
	header("location:index.php"); //to redirect back to "index.php" after logging out
	exit();


?>