<?php 
//include("users.php");
session_start();
if (!isset($_SESSION['login_user'])){
	header('Location:index.php');
	//$use
}?>

<?php
    function print_Table()
	{
		$conn= mysqli_connect('localhost','root',''); 
		$db=mysqli_select_db($conn,'library_mgmt');	
		echo"sucess";
	
		
	}
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>home</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<script>
function sample()
{

	var eleDiv = document.getElementById("divName");

    eleDiv.style.visibility = "visible";
	
	
}
</script>
	
<body onload='window.location.hash="#btnPrint";'>

<div id="wrapper">
<div id="logo">
	<h1><a href="#">Library Management System</a></h1>
	<div class="profilename_sec">
	<label><?php echo $_SESSION['users_details']['username'];?></label>
	<img src="images/usersico.png" class="usericon"/>
	</div>
	<p>THIAGARAJAR COLLEGE OF ENGINEERING</p>
</div>
<div id="header" class="sam" style="height:430px">
	<div id="menu_admin" style="background-size:308px 430px;">
		<ul>
			<li class="current_page_item"><a href="home.php">Home</a></li>
			<?php if($_SESSION['users_details']['role'] == 1){?>
			<li><a href="search.php">Search</a></li>
			<li><a href="user_issuedbook.php">Issued Books</a></li>
			<li><a href="users_renuedbook.php">Renued Books</a></li>
			<li><a href="users_returned.php">Returned Book</a></li>
			
						
			
			<?php }
			else if($_SESSION['users_details']['role'] == 2){?>
			<li><a href="issue_book.php">Manage Books</a></li>
			<li><a href="mng_usr_lib.php">Manage users</a></li>
			<li><a href="search.php">Search</a></li>
			<?php }else{?>
			<li><a href="mng_usr.php">Manage Librian</a></li>
			<li><a href="mng_book.php">Manage Book Details</a></li>
			<li><a href="mng_usr.php">Manage Users</a></li>
			<li><a href="search.php">Search</a></li>
			<li><a href="mng_usr_lib.php">Generate Report</a></li>
			<li><a href="history.php">History</a></li>
			<li><a href="Bulky.php">Upload File</a></li>
			
			<?php }?>
			<li><a href="logout.php">logout</a></li>
		</ul>
	</div>
	<div id="gallery"><img src="images/sam.jpg" width="680" height="428" alt="" /></div>
	
</div>
<div>
<div class="main-content">
<div class="head_text" id="test" action="issue_book.php">
	<p>
	search</p>
	<form class="bookstatus_form" id="book_status" action=search1.php method=POST>
		<label>Choose By Categry</label>
		<select name="lib_choice" >
			<option>----Choose any one----</option>
			<option>ACCESSION_NO</option>
			<option>AUTHOR</option>
			<option>TITLE_OF_THE_BOOKS</option>
			<option>STATUS</option>
			
		</select>
		<label>Enter the Attribute of Book:</label> 
		<input type="text" name="s_id" class="bookid_txt" placeholder="Search"  id="sid_txt"/>
		<input type='submit' name="update_lib" class="btn"  id="btnPrint"/>
	</form>
</div>
</div>
</html>