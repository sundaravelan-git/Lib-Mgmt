<!DOCTYPE html>
<!-- saved from url=(0037)https://librarycom.000webhostapp.com/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	
	<title>Home</title>
	<!--<base href="https://librarycom.000webhostapp.com/">--><base href=".">
			<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		<meta name="description" content="">
	<meta name="keywords" content="">
	<!-- Facebook Open Graph -->
	<meta name="og:title" content="Home">
	<meta name="og:description" content="">
	<meta name="og:image" content="">
	<meta name="og:type" content="article">
	<meta name="og:url" content="https://librarycom.000webhostapp.com/">
	<!-- Facebook Open Graph end -->
		
	<link href="./Home_files/bootstrap.min.css" rel="stylesheet" type="text/css">
	<script src="./Home_files/jquery-1.11.3.min.js.download" type="text/javascript"></script>
	<script src="./Home_files/bootstrap.min.js.download" type="text/javascript"></script>
	<script src="./Home_files/main.js.download" type="text/javascript"></script>

	<link href="./Home_files/site.css" rel="stylesheet" type="text/css">
	<link href="./Home_files/common.css" rel="stylesheet" type="text/css">
	<link href="./Home_files/1.css" rel="stylesheet" type="text/css">
	
	<script type="text/javascript">var currLang = 'en';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_cs_row_1" class="wb-cs-row"><div id="wb_cs_col_2" class="wb-cs-col"><div id="wb_cs_row_3" class="wb-cs-row"><div id="wb_cs_col_4" class="wb-cs-col"><div id="wb_element_instance2" class="wb_element wb_element_picture wb-cs-elem"><img alt="gallery/thiagarajar-college-of-engineering" src="./Home_files/57a81e0be1608b0a6b094b4b642440e6_40x37.png"></div></div><div id="wb_cs_col_5" class="wb-cs-col"><div id="wb_element_instance1" class="wb_element wb-cs-elem" style=" line-height: normal;"><h4 class="wb-stl-pagetitle">Thiagarajar college of Enggineering.</h4>
</div></div><div class="wb-cs-clear"></div></div></div><div id="wb_cs_col_6" class="wb-cs-col wb-cs-right"><div id="wb_element_instance0" class="wb_element wb-menu wb-menu-mobile wb-cs-elem"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu"><li class="active"><a href="index.html" target="_self" title="HOME">HOME</a></li><li><a href="About us.html" target="_self" title="About us">About us</a></li><li><a href="Contacts.html" target="_self" title="Contacts">Contacts</a></li><li><a href="index1.php" target="_self" title="Login">Login</a></li></ul><div class="clearfix"></div></div></div><div class="wb-cs-clear"></div></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_cs_row_9" class="wb-cs-row"><div id="wb_cs_col_10" class="wb-cs-col"><div id="wb_element_instance11" class="wb_element wb-cs-elem" style=" line-height: normal;"><p style="text-align: justify;">&nbsp;</p>

<h1 class="wb-stl-heading1" style="text-align: center;">“<span style="color:#inherit;">The very existence of libraries affords the best evidence that we may yet have hope for the future of man”&nbsp;<br>
―&nbsp;T.S. Eliot</span></h1>

<p>&nbsp;</p>
</div></div><div class="wb-cs-clear"></div></div><div id="wb_cs_row_11" class="wb-cs-row"><div id="wb_cs_col_12" class="wb-cs-col"><div id="wb_element_instance14" class="wb_element wb_element_shape wb-cs-elem"><div class="wb_shp"></div><div class="wb-elm-ch-wrp"><div id="wb_cs_row_13" class="wb-cs-row auto-height"><div id="wb_cs_col_14" class="wb-cs-col" style=""><div id="wb_element_instance4" class="wb_element wb_element_shape wb-cs-elem" style="height: 293px;"><div class="wb_shp"></div><div class="wb-elm-ch-wrp"><div id="wb_cs_row_15" class="wb-cs-row"><div id="wb_cs_col_16" class="wb-cs-col"><div id="wb_element_instance8" class="wb_element wb_element_picture wb-cs-elem"><img alt="gallery/01" src="./Home_files/ace894a24332c32516ceda417fd49802_380x120.jpg"></div></div><div class="wb-cs-clear"></div></div><div id="wb_cs_row_17" class="wb-cs-row"><div id="wb_cs_col_18" class="wb-cs-col"><div id="wb_element_instance7" class="wb_element wb-cs-elem" style=" line-height: normal;"><h1 class="wb-stl-heading1" style="text-align: center;">Books</h1>

<p>&nbsp;</p>

<p class="wb-stl-normal" style="text-align: center;"><span style="background-color: transparent; color: rgb(255, 255, 255); font-family: Georgia, serif; font-size: 13px;">You will find the latest information about us on this page. </span></p>
</div></div><div class="wb-cs-clear"></div></div><div class="wb-cs-clear"></div></div></div></div><div id="wb_cs_col_19" class="wb-cs-col"><div id="wb_element_instance5" class="wb_element wb_element_shape wb-cs-elem" style="height: 293px;"><div class="wb_shp"></div><div class="wb-elm-ch-wrp"><div id="wb_cs_row_20" class="wb-cs-row"><div id="wb_cs_col_21" class="wb-cs-col"><div id="wb_element_instance9" class="wb_element wb_element_picture wb-cs-elem"><img alt="gallery/03" src="./Home_files/b6c88028e688f4aceb5df4999e58f2e3_380x120.jpg"></div></div><div class="wb-cs-clear"></div></div><div id="wb_cs_row_22" class="wb-cs-row"><div id="wb_cs_col_23" class="wb-cs-col"><div id="wb_element_instance12" class="wb_element wb-cs-elem" style=" line-height: normal;"><h1 class="wb-stl-heading1" style="text-align: center;">Research</h1>

<p>&nbsp;</p>

<p class="wb-stl-normal" style="text-align: center;"><span style="color: rgb(255, 255, 255); font-family: Georgia, serif; font-size: 13px; line-height: 22px; background-color: transparent;">You will find the latest Reserch papers of Our College.</span></p>

<p class="wb-stl-normal" style="text-align: center;">&nbsp;</p>

<p class="wb-stl-normal" style="text-align: center;"><span style="color: rgb(255, 255, 255); font-family: Georgia, serif; font-size: 13px; line-height: 22px; background-color: transparent;">&nbsp;WILL BE UPDATED SOON</span></p>
</div></div><div class="wb-cs-clear"></div></div><div class="wb-cs-clear"></div></div></div></div><div id="wb_cs_col_24" class="wb-cs-col"><div id="wb_element_instance6" class="wb_element wb_element_shape wb-cs-elem" style="height: 293px;"><div class="wb_shp"></div><div class="wb-elm-ch-wrp"><div id="wb_cs_row_25" class="wb-cs-row"><div id="wb_cs_col_26" class="wb-cs-col"><div id="wb_element_instance10" class="wb_element wb_element_picture wb-cs-elem"><img alt="gallery/02" src="./Home_files/a82fefa6742b533e219153e3566cc8f4_380x120.jpg"></div></div><div class="wb-cs-clear"></div></div><div id="wb_cs_row_27" class="wb-cs-row"><div id="wb_cs_col_28" class="wb-cs-col"><div id="wb_element_instance13" class="wb_element wb-cs-elem" style=" line-height: normal;"><h1 class="wb-stl-heading1" style="text-align: center;">Agenda</h1>

<p>&nbsp;</p>

<p><span style="color:#fff7ff;">Our Main obective is to provide an unprdictable knowledge to the students apart from the curriculam through the library.</span></p>
</div></div><div class="wb-cs-clear"></div></div><div class="wb-cs-clear"></div></div></div></div><div class="wb-cs-clear"></div></div><div class="wb-cs-clear"></div></div></div></div><div class="wb-cs-clear"></div></div><div id="wb_element_instance15" class="wb_element" style="width: 100%; display: none;">
						<script type="text/javascript">
				$(function() {
					$("#wb_element_instance15").hide();
				});
			</script>
						</div></div>
<div class="vbox wb_container" id="wb_footer" style="">
	
<div id="wb_cs_row_7" class="wb-cs-row"><div id="wb_cs_col_8" class="wb-cs-col"><div id="wb_element_instance3" class="wb_element wb-cs-elem" style=" line-height: normal;"><p>To Access OPAC Link <a href="http://lib2.tce.edu/AutoLib/opac.jsp" target="_blank">Please Click Here</a></p>
</div></div><div class="wb-cs-clear"></div></div></div><div class="wb_sbg"></div></div><div style="text-align: right;position: fixed;z-index:9999999;bottom: 0; width: 100%;cursor: pointer;line-height: 0;"><a title="Hosted on free web hosting 000webhost.com. Host your own website for FREE." target="_blank" href="https://www.000webhost.com/?utm_source=000webhostapp&amp;utm_campaign=000_logo&amp;utm_medium=website_librarycom&amp;utm_content=footer_img"></a></div>



</body></html>