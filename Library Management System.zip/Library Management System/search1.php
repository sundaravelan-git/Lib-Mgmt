<?php 
//include("users.php");
session_start();
if (!isset($_SESSION['login_user'])){
	header('Location:index.php');
	//$use
}?>

<?php
    function print_Table()
	{
		$conn= mysqli_connect('localhost','root',''); 
		$db=mysqli_select_db($conn,'library_mgmt');	
		echo"sucess";
	
		
	}
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>home</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<script type="text/javascript" src="jquery.min.js"></script>
    <script type="text/javascript">
        $("#btnPrint").live("click", function () {
			
            var divContents = $("#main_content_id").html();
            var printWindow = window.open('', '', 'height=400,width=800');
            //printWindow.document.write('<html><head><h2 align="center">search results</title>');
            printWindow.document.write('</head><body >');
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>
	
<body>
<div id="wrapper">
<div id="logo">
	<h1><a href="#">Library Management System</a></h1>
	<div class="profilename_sec">
	<label><?php echo $_SESSION['users_details']['username'];?></label>
	<img src="images/usersico.png" class="usericon"/>
	</div>
	<p>THIAGARAJAR COLLEGE OF ENGINEERING</p>
</div>
<div id="header" class="sam" style="height:430px">
	<div id="menu_admin" style="background-size:308px 430px;">
		<ul>
			<li class="current_page_item"><a href="home.php">Home</a></li>
			<?php if($_SESSION['users_details']['role'] == 1){?>
			<li><a href="search.php">Search</a></li>
			<li><a href="user_issuedbook.php">Issued Books</a></li>
			<li><a href="users_renuedbook.php">Renued Books</a></li>
			<li><a href="users_returned.php">Returned Book</a></li>
						
			
			<?php }
			else if($_SESSION['users_details']['role'] == 2){?>
			<li><a href="issue_book.php">Manage Books</a></li>
			<li><a href="mng_usr_lib.php">Manage users</a></li>
			<li><a href="search.php">Search</a></li>
			<?php }else{?>
			<li><a href="mng_lib.php">Manage Librian</a></li>
			<li><a href="mng_book.php">Manage Book Details</a></li>
			<li><a href="mng_usr.php">Manage Users</a></li>
			<li><a href="search.php">Search</a></li>
			<li><a href="mng_usr_lib.php">Generate Report</a></li>
			<li><a href="history.php">History</a></li>
			<li><a href="Bulky.php">Upload File</a></li>
			<?php }?>
			<li><a href="logout.php">logout</a></li>
		</ul>
	</div>
	<div id="gallery"><img src="images/sam.jpg" width="680" height="428" alt="" /></div>
	
</div>
<div>
<div class="main-content" id='main_content_id' align=center>
<div class="head_text" id="test" action="issue_book.php">
	<p>search results</p>
	<form  id="book_status" action='search1.php' method='POST'>
		<?php

$conn= mysqli_connect('localhost','root',''); 
$db=mysqli_select_db($conn,'library_mgmt');	
$query=$_POST['s_id'];
$attr=$_POST['lib_choice'];
$query = htmlspecialchars($query); 
$query = mysql_real_escape_string($query);
if($attr!="----Choose any one----")
 $result = mysqli_query($conn,"select * from sheet1 where ".$attr." like '%".$query."%' ;") or die(mysql_error());
else
	{echo"<script>alert('Please Choose the Correct option');</script>";}
        
         
   
	   echo "<table border=1>
				<tr>
				<th>ACCESSION NUMBER</th>
				<th>AUTHOR</th>
				<th>TITLE OF THE BOOKS</th>
				<th>STATUS</th>
				</tr>";
			
	if(mysqli_num_rows($result)){
           while($results = mysqli_fetch_array($result)){
             
           
				echo"	
				
				<tr>
					<td>
					'".$results['ACCESSION_NO']."'
					</td>
					
					<td>
					'".$results['AUTHOR']."'
					</td>
					
					<td>
					'".$results['TITLE_OF_THE_BOOKS']."'
					</td>
					
					<td>
					'".$results['STATUS']."'
					</td>
				</tr>";
                // posts results gotten from database(title and text) you can also show id ($results['id'])
            }
			echo"</table>";
             
        }
        else{ // if there is no matching rows do following
            echo "No results";
			
		
        }
		
		
		if($_SESSION['users_details']['role'] == 1)
		{
			
							mysqli_query($conn,"insert into history_book values('".$results['ACCESSION_NO']."','".$results['TITLE_OF_THE_BOOKS']."','".$results['STATUS']."',CURDATE(),'searched')");

		}
         

?>
	</form>
</div>
<td colspan="4"><B><Button id="btnPrint">Prepare a report of your Usage</Button></td>
</div>
</html>