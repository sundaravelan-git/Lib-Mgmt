<?php
 session_start();
 echo time();
    if (isset($_POST['butt_login']))
    {     
    $conn= mysqli_connect('localhost','root',''); 
	$db=mysqli_select_db($conn,'library_mgmt');	
	

    $eid=$_POST['email'];
    $pwd=$_POST['pwd'];
   
   $result = mysqli_query($conn,"select * from user where email='".$eid."' and pwd='".$pwd."';");
   
	//print_r(mysqli_fetch_all($result,MYSQLI_ASSOC));exit;
	$result_all = mysqli_fetch_all($result,MYSQLI_ASSOC);
	if(mysqli_num_rows($result))
    {
		$_SESSION['login_user']=$eid; 
//		echo $_SESSION['login_user'];exit;
		foreach($result_all as $row){
			$data['role'] = $row['role'];
			$data['userid'] = $row['id'];
			$data['email'] = $row['email'];
			$data['username'] = $row['uname'];
			$_SESSION['users_details'] = $data;
		}
		header('Location:home.php');
      }
      else
      {
		header("Refresh: 0; url=index.php");
		echo"<script>alert('User Name Or Password Invalid!');</script>";
		die;
    }
	if(isset($_GET['user_name']))
		session_unregister('login_user');
    }
	else if(isset($_SESSION['login_user'])){
		header('Location:./home.php');
	}
	else
	{
		//echo $_SESSION['login_user'];
		header('Location:index.php');
	}
?>