<?php 
//include("users.php");
session_start();
if (!isset($_SESSION['login_user'])){
	header('Location:index.php');
	//$use
}?>


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>home</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<style>

</style>
<body>
<div id="wrapper">
<div id="logo">
	<h1><a href="#">Library Management System</a></h1>
	<div class="profilename_sec">
	<label><?php echo $_SESSION['users_details']['username'];?></label>
	<img src="images/usersico.png" class="usericon"/>
	</div>
	<p>THIAGARAJAR COLLEGE OF ENGINEERING</p>
</div>
<div id="header">
	<div id="menu">
		<ul>
			<li class="current_page_item"><a href="home.php">Home</a></li>
			<?php if($_SESSION['users_details']['role'] == 1){?>
			<li><a href="#">Dashboard</a></li>
			<li><a href="#">Issued Books</a></li>
			<li><a href="#">Renued Books</a></li>
			<li><a href="#">Returned Book</a></li>
			
			<?php }
			else if($_SESSION['users_details']['role'] == 2){?>
			<li><a href=#">Manage Books</a></li>
			<li><a href="reportadmin.php">User_report Generation</a></li>
			
			<?php }else{?>
			<li><a href="#">Manage Librian</a></li>
			<li><a href="mng_book.php">Manage Book Details</a></li>
			<li><a href="mng_usr.php">Manage Users</a></li>
			<li><a href="search.php">Search</a></li>
				<li><a href="reportadmin.php">Generate Report</a></li>
			<?php }?>
			<li><a href="logout.php">logout</a></li>
		</ul>
	</div>
	
	<div id="gallery"><img src="images/sam.jpg" width="683" height="340" alt="" /></div>
	
</div>
<div class="main-content">
<div class="head_text" id="test" action="issue_book.php">
	<p>Manage Librarian</p>
	<form class="bookstatus_form" id="book_status">
		<label>Email-ID:</label> 
		<input type="text" name="u_eid" class="bookid_txt" placeholder="Enter your Email-ID"  id="eid_txt"/>
		<label>Name :</label>
		<input type="text" name="u_name" placeholder="Enter Your name" class="userid_txt" id="u_name_txt"/>
		<label>Password :</label>
		<input type="password" name="u_pwd" placeholder="Enter your password" class="userid_txt" id="u_pwd_txt"/>
		<label>Confirm password :</label>
		<input type="text" name="u_pwd_confirm" placeholder="confirm  password" class="userid_txt" id="u_con_pwd_txt"/>
		<select name="lib_choice">
			<option>----Choose any one----</option>
			<option>Add_Librarian</option>
			<option>Remove_librarian</option>
			<option>Edit_Detials_of_Librarian</option>
		</select>
		<input type="button" name="update_lib" class="btn" value="Submit"/>
	</form>
</div>
</div>
</div>
</html>