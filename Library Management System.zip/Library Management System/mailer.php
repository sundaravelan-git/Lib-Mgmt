<?php

require 'PHPMailerAutoload.php';

$mail = new PHPMailer();

$mail->SMTPDebug = 2; //Alternative to above constant

$mail->IsSMTP();
$mail->Mailer = 'smtp';
$mail->SMTPAuth = true;
$mail->Host = 'smtp.gmail.com'; // "ssl://smtp.gmail.com" didn't worked
$mail->Port = 465;
$mail->SMTPSecure = 'ssl';
// or try these settings (worked on XAMPP and WAMP):

 
 
$mail->Username = "gurunarayanancse@gmail.com";
$mail->Password = "tcecseguru";
 
$mail->IsHTML(true); // if you are going to send HTML formatted emails
$mail->SingleTo = true; // if you want to send a same email to multiple users. multiple emails will be sent one-by-one.
 
$mail->From = "gurunarayanancse@gmail@gmail.com";
$mail->FromName = "LMSTCE";
 

$mail->addAddress("gurunarayanancse@gmail.com","User 2");

 
$mail->Subject = "confirm message";
$mail->Body = "Hi, welcome first mail from ranar";
if(!$mail->Send())
    echo "Message was not sent <br />PHPMailer Error: " . $mail->ErrorInfo;
else
	echo "<html><script>alert('Sucess');window.location='3.php';</script></html>";
   
?>
