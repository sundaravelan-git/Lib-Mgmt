<?php 
$conn= mysqli_connect('localhost','root',''); 
$db=mysqli_select_db($conn,'library_mgmt');


	$acc_no  = $_POST['acc_no'];
	$author    = $_POST['author'];
	$book    = $_POST['book_name'];
	$status=$_POST['book_status'];
	$opt=$_POST['opr'];
	
	
	if($opt=='Insert Data')
	{
	$result=mysqli_query($conn,"insert into sheet1 values('".$acc_no."','".$author."','".$book."','".$status."')");
	mysqli_query($conn,"insert into history_book values('".$acc_no."','".$book."','".$status."',CURDATE(),'inserted')");

	
	if($result)
	{
				echo"<script type='text/javascript'>alert('sucessfull insertion');window.location='mng_book.php';</script>";

	}
	else
	{
				echo"<script type='text/javascript'>alert('failure insertion');window.location='mng_book.php';</script>";

	}
		
	}
	else if($opt=='Update Data')
	{
		
			$result=mysqli_query($conn,"update sheet1 set AUTHOR='".$author."',TITLE_OF_THE_BOOKS='".$book ."',STATUS='".$status."' where ACCESSION_NO='".$acc_no ."';");
				mysqli_query($conn,"insert into history_book values('".$acc_no."','".$book."','".$status."',CURDATE(),'updated')");

	if($result)
	{
				echo"<script type='text/javascript'>alert('sucessfull updation');window.location='mng_book.php';</script>";

	}
	else
	{
				echo"<script type='text/javascript'>alert('failure updation');window.location='mng_book.php';</script>";

	}
	}
	else{
		$result=mysqli_query($conn,"delete from sheet1 where ACCESSION_NO='".$acc_no ."';");
						mysqli_query($conn,"insert into history_book values('".$acc_no."','".$book."','".$status."',CURDATE(),'deleted')");

	if($result)
	{
				echo"<script type='text/javascript'>alert('sucessfull deletion');window.location='mng_book.php';</script>";

	}
	else
	{
				echo"<script type='text/javascript'>alert('failure deletion')window.location='mng_book.php';</script>";

	}
		
	}
		

?>