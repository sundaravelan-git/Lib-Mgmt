<?php 
$conn= mysqli_connect('localhost','root',''); 
$db=mysqli_select_db($conn,'library_mgmt');


	$email   = $_POST['email'];
	$user    = $_POST['user'];
	$pwd     = $_POST['password'];
	
	
	
	$result=mysqli_query($conn,"insert into user values('1',,'$email','$user','$pwd')");
	if($result)
	{
				echo"<script type='text/javascript'>alert('sucessfull insertion');window.location='index.php';</script>";

	}
	else
	{
				echo"<script type='text/javascript'>alert('failure insertion');window.location='index.php';</script>";

	}
			
	
	
?> 