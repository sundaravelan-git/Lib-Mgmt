<?php 
//include("users.php");

if (isset($_GET['Message'])) {
print '<script type="text/javascript">alert("' . $_GET['Message'] . '");</script>';}
session_start();
if (!isset($_SESSION['login_user'])){
	header('Location:index.php');
	
	//$use

}?>

<script>
function myFunction() {
    var x = document.getElementById("upload_Main").value;
    if(x=='Book')
	{
		document.getElementById("upCat1").style.visibility = "visible";
		document.getElementById("fileToUpload1").style.visibility = "visible";
				document.getElementById("upCat2").style.visibility = "hidden";

				document.getElementById("submit1").style.visibility = "visible";

		
		
	}
	else if(x=='User')
	{
		document.getElementById("upCat2").style.visibility = "visible";
		document.getElementById("fileToUpload1").style.visibility = "visible";
				document.getElementById("upCat1").style.visibility = "hidden";
			document.getElementById("status1").style.visibility = "hidden";		

				document.getElementById("submit1").style.visibility = "visible";

		
	}
	else{
		alert('Invalid option');
	}
}

function fun()
{
	
	 var x = document.getElementById("upCat1").value;
	   if(x==2)
	{
		document.getElementById("status1").style.visibility = "visible";		
		
	}
	else{
			document.getElementById("status1").style.visibility = "hidden";		
	
	}
}
</script>


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>home</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<style>

</style>
<body onload='window.location.hash="#btnPrint";'>
<div id="wrapper">
<div id="logo">
	<h1><a href="#">Library Management System</a></h1>
	<div class="profilename_sec">
	<label><?php echo $_SESSION['users_details']['username'];?></label>
	<img src="images/usersico.png" class="usericon"/>
	</div>
	<p>THIAGARAJAR COLLEGE OF ENGINEERING</p>
</div>
<div id="header" class="sam" style="height:430px">
	<div id="menu_admin" style="background-size:308px 430px;">
		<ul>
			<li class="current_page_item"><a href="home.php">Home</a></li>
			<?php if($_SESSION['users_details']['role'] == 1){?>
			<li><a href="#">Dashboard</a></li>
			<li><a href="#">Issued Books</a></li>
			<li><a href="#">Renued Books</a></li>
			<li><a href="#">Returned Book</a></li>
			
			<?php }
			else if($_SESSION['users_details']['role'] == 2){?>
			<li><a href=#">Manage Books</a></li>
			
			
			<?php }else{?>
			<li><a href="mng_usr.php">Manage Librian</a></li>
			<li><a href="mng_book.php">Manage Book Details</a></li>
			<li><a href="mng_usr.php">Manage Users</a></li>
			<li><a href="search.php">Search</a></li>
			<li><a href="mng_usr_lib.php">Generate Report</a></li>
			<li><a href="history.php">History</a></li>
			<li><a href="Bulky.php">Upload File</a></li>
			
			
			
			<?php }?>
			<li><a href="logout.php">logout</a></li>
		</ul>
	</div>
	
	<div id="gallery"><img src="images/sam.jpg" width="680" height="428" alt="" /></div>
	
</div>
<div class="main-content">
<div class="head_text" id="test" action="issue_book.php">
	<center>
		<pre align="center">
		Please Upload the File to Change the Bulk Modifications..
		
		[Note The File Should be in the CSV format]
		<br/>
		</pre>
	</center>	
	
			<form  id="book_status" class="bookstatus_form" action='upload.php' method='POST' enctype="multipart/form-data">
What You are going to Modify:
	<select name="upCatMain" id="upload_Main"  onchange="myFunction()">
		<option>--------Select your option--------- </option>
		<option value="Book">Books</option>
		<option value="User">Users</option>
	</select>
	
	<select name="upCatBook" id="upCat1" style="visibility:hidden" onchange="fun()">
		<option value=1>Insert Book</option>
		<option value=2>Update Book Status</option>
	</select>
	
	<input type="text" name="status" id="status1" placeholder="Please type the status Here" style="Visibility:hidden"/>
		
	<select name="upCatUser" id="upCat2" style="visibility:hidden">
		<option value=1>Insert User</option>
		<option value=2>Delete User</option>
	</select>
		
	 
	    <input type="file"  id="fileToUpload1" name="fileToUpload" style="visibility:hidden"/>  
	    <input type="submit" value="Upload File" name="submit" id="submit1" style="visibility:hidden"/>  
	
	</form>  
	
	</form>
</div>
</div>
</div>
</html>